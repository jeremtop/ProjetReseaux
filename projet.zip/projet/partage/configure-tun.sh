sudo ip address add 172.16.2.1/28 dev tun0
ip link set tun0 up
