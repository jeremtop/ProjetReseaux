sudo ip route add 172.16.2.144/28 via 172.16.2.10 dev tun0
